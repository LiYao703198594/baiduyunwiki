const prefs = {
  'enabled': false,
  'overwrite-origin': true,
  'overwrite-methods': true,
  'methods': ['GET', 'POST', 'OPTIONS']
  //'methods': ['GET', 'PUT', 'POST', 'DELETE', 'HEAD', 'OPTIONS', 'PATCH']
}

const cors = {}
cors.onHeadersReceived = ({responseHeaders}) => {
  if (prefs['overwrite-origin'] === true) {
    const o = responseHeaders.find(({name}) => name.toLowerCase() === 'access-control-allow-origin')
    if (o) {
      o.value = '*'
    } else {
      responseHeaders.push({
        'name': 'Access-Control-Allow-Origin',
        'value': '*'
      })
    }
  }
  if (prefs['overwrite-methods'] === true) {
    const o = responseHeaders.find(({name}) => name.toLowerCase() === 'access-control-allow-methods')
    if (o) {
      o.value = prefs.methods.join(', ')
    } else {
      responseHeaders.push({
        'name': 'Access-Control-Allow-Methods',
        'value': prefs.methods.join(', ')
      })
    }
  }
  return {responseHeaders}
}
cors.install = () => {
  cors.remove()
  const extra = ['blocking', 'responseHeaders']
  if (/Firefox/.test(navigator.userAgent) === false) {
    extra.push('extraHeaders')
  }
  chrome.webRequest.onHeadersReceived.addListener(cors.onHeadersReceived, {
    urls: ['<all_urls>']
  }, extra)
  console.log(222)
}
cors.remove = () => {
  chrome.webRequest.onHeadersReceived.removeListener(cors.onHeadersReceived)
}

console.log(prefs.enabled)

if (prefs.enabled) {
  cors.install()
} else {
  cors.remove()
}


